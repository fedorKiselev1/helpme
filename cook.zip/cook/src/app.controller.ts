import {
  Controller,
  Get,
  Param,
  Post,
  Body,
  Put,
  Delete,
} from '@nestjs/common';
import { UserService } from './auth/auth.service';
import { User as UserModel, UserRole } from './../prisma/generated/client.js';

@Controller()
export class AppController {
  constructor(
    private readonly UserService: UserService,
  ) {}

  @Post('user')
  async signupUser(
    @Body() userData: {email: string; password: string; displayName: string; picture?: string;},
  ): Promise<UserModel> {
    return this.UserService.createUser(userData);
  }

}